-- ============================================================
-- SupaChat v2 — Script de configuração do banco de dados
-- Cole no SQL Editor do Supabase e execute
-- ============================================================

-- Se já tinha v1, adiciona as colunas novas:
ALTER TABLE salas ADD COLUMN IF NOT EXISTS criador TEXT DEFAULT '';
ALTER TABLE salas ADD COLUMN IF NOT EXISTS admins  TEXT DEFAULT '';

-- Caso não tenha as tabelas ainda, cria do zero:
CREATE TABLE IF NOT EXISTS salas (
    id         BIGSERIAL PRIMARY KEY,
    nome       TEXT NOT NULL UNIQUE,
    criador    TEXT NOT NULL DEFAULT '',
    admins     TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS mensagens (
    id         BIGSERIAL PRIMARY KEY,
    sala       TEXT NOT NULL,
    autor      TEXT NOT NULL,
    texto      TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_mensagens_sala_id ON mensagens (sala, id);

-- ─── RLS ───────────────────────────────────────────────────
ALTER TABLE salas     ENABLE ROW LEVEL SECURITY;
ALTER TABLE mensagens ENABLE ROW LEVEL SECURITY;

-- Remover policies antigas se existirem
DROP POLICY IF EXISTS "salas_select"     ON salas;
DROP POLICY IF EXISTS "salas_insert"     ON salas;
DROP POLICY IF EXISTS "salas_update"     ON salas;
DROP POLICY IF EXISTS "salas_delete"     ON salas;
DROP POLICY IF EXISTS "mensagens_select" ON mensagens;
DROP POLICY IF EXISTS "mensagens_insert" ON mensagens;
DROP POLICY IF EXISTS "mensagens_delete" ON mensagens;

-- Salas: leitura, criação, atualização e exclusão públicas
CREATE POLICY "salas_select" ON salas FOR SELECT USING (true);
CREATE POLICY "salas_insert" ON salas FOR INSERT WITH CHECK (true);
CREATE POLICY "salas_update" ON salas FOR UPDATE USING (true);
CREATE POLICY "salas_delete" ON salas FOR DELETE USING (true);

-- Mensagens: leitura, envio e exclusão públicas
CREATE POLICY "mensagens_select" ON mensagens FOR SELECT USING (true);
CREATE POLICY "mensagens_insert" ON mensagens FOR INSERT WITH CHECK (true);
CREATE POLICY "mensagens_delete" ON mensagens FOR DELETE USING (true);

-- ─── Salas padrão ──────────────────────────────────────────
INSERT INTO salas (nome, criador, admins) VALUES
    ('geral',     'sistema', ''),
    ('aleatório', 'sistema', ''),
    ('ajuda',     'sistema', '')
ON CONFLICT (nome) DO NOTHING;
