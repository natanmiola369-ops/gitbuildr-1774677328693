package com.supachat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Vibrator;
import android.os.VibrationEffect;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ChatService extends Service {

    public static final String ACTION_NOVA_MSG    = "com.supachat.NOVA_MSG";
    public static final String EXTRA_AUTOR        = "autor";
    public static final String EXTRA_TEXTO        = "texto";
    public static final String EXTRA_SALA         = "sala";

    private static final String CHANNEL_FOREGROUND = "supachat_fg";
    private static final String CHANNEL_MSGS       = "supachat_msgs";
    private static final int    NOTIF_FG_ID        = 1;
    private static final int    NOTIF_MSG_BASE      = 100;

    private static final String SUPABASE_URL = "https://umeoupxrryeywomygvdo.supabase.co";
    private static final String SUPABASE_KEY = "sb_publishable_TsVRloDj3_tsZFGIMO5kLg_ZJhlmd0a";

    private OkHttpClient http;
    private Handler     handler;
    private Runnable    pollingRunnable;
    private SharedPreferences prefs;

    private String salaMonitorada = "";
    private long   ultimoIdBg     = 0;
    private int    notifMsgId     = NOTIF_MSG_BASE;

    // ─── Ciclo de vida ─────────────────────────────────────────────────────
    @Override
    public void onCreate() {
        super.onCreate();
        http    = new OkHttpClient();
        handler = new Handler(Looper.getMainLooper());
        prefs   = getSharedPreferences("supachat", MODE_PRIVATE);
        criarCanais();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            salaMonitorada = intent.getStringExtra("sala");
            if (salaMonitorada == null) salaMonitorada = "";
            ultimoIdBg = intent.getLongExtra("ultimoId", 0);
        }
        startForeground(NOTIF_FG_ID, criarNotificacaoForeground());
        iniciarPolling();
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        pararPolling();
    }

    // ─── Canais de notificação ─────────────────────────────────────────────
    private void criarCanais() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);

            // Canal foreground (silencioso)
            NotificationChannel fg = new NotificationChannel(
                    CHANNEL_FOREGROUND, "SupaChat ativo", NotificationManager.IMPORTANCE_LOW);
            fg.setDescription("Mantém o chat ativo em segundo plano");
            nm.createNotificationChannel(fg);

            // Canal de mensagens (com som e vibração)
            NotificationChannel msgs = new NotificationChannel(
                    CHANNEL_MSGS, "Novas mensagens", NotificationManager.IMPORTANCE_HIGH);
            msgs.setDescription("Notificações de novas mensagens");
            msgs.enableVibration(true);
            msgs.setVibrationPattern(new long[]{0, 250, 150, 250});
            Uri somPadrao = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            msgs.setSound(somPadrao, aa);
            nm.createNotificationChannel(msgs);
        }
    }

    // ─── Notificação foreground ────────────────────────────────────────────
    private Notification criarNotificacaoForeground() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        String titulo = salaMonitorada.isEmpty()
                ? "SupaChat ativo"
                : "SupaChat — #" + salaMonitorada;

        return new NotificationCompat.Builder(this, CHANNEL_FOREGROUND)
                .setContentTitle(titulo)
                .setContentText("Monitorando mensagens em segundo plano")
                .setSmallIcon(android.R.drawable.ic_dialog_email)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    // ─── Polling ───────────────────────────────────────────────────────────
    private void iniciarPolling() {
        pararPolling();
        pollingRunnable = new Runnable() {
            @Override public void run() {
                if (!salaMonitorada.isEmpty()) {
                    buscarNovaMensagens();
                }
                handler.postDelayed(this, 5000);
            }
        };
        handler.postDelayed(pollingRunnable, 5000);
    }

    private void pararPolling() {
        if (pollingRunnable != null) {
            handler.removeCallbacks(pollingRunnable);
            pollingRunnable = null;
        }
    }

    private void buscarNovaMensagens() {
        String nomeUsuario = prefs.getString("nome", "");
        String url = SUPABASE_URL + "/rest/v1/mensagens"
                + "?sala=eq." + salaMonitorada
                + "&id=gt." + ultimoIdBg
                + "&order=id.asc";

        Request req = new Request.Builder()
                .url(url)
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .get()
                .build();

        http.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {}
            @Override public void onResponse(Call call, Response resp) throws IOException {
                final String body = resp.body().string();
                try {
                    JSONArray arr = new JSONArray(body);
                    String nomeLocal = prefs.getString("nome", "");
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject msg = arr.getJSONObject(i);
                        long id     = msg.getLong("id");
                        String autor = msg.getString("autor");
                        String texto = msg.getString("texto");
                        if (id > ultimoIdBg) ultimoIdBg = id;
                        if (!autor.equals(nomeLocal)) {
                            notificarMensagem(autor, texto, salaMonitorada);
                            enviarBroadcast(autor, texto, salaMonitorada);
                        }
                    }
                } catch (Exception e) { /* silencioso */ }
            }
        });
    }

    // ─── Notificação de mensagem ───────────────────────────────────────────
    private void notificarMensagem(String autor, String texto, String sala) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Uri somPadrao = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_MSGS)
                .setSmallIcon(android.R.drawable.ic_dialog_email)
                .setContentTitle(autor + " em #" + sala)
                .setContentText(texto)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(texto))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setSound(somPadrao)
                .setVibrate(new long[]{0, 250, 150, 250})
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(notifMsgId++, builder.build());

        // Vibração extra via Vibrator para garantir
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createWaveform(
                            new long[]{0, 250, 150, 250}, -1));
                } else {
                    v.vibrate(new long[]{0, 250, 150, 250}, -1);
                }
            }
        } catch (Exception e) { /* ignora */ }
    }

    // ─── Broadcast para a Activity (se estiver aberta) ─────────────────────
    private void enviarBroadcast(String autor, String texto, String sala) {
        Intent i = new Intent(ACTION_NOVA_MSG);
        i.putExtra(EXTRA_AUTOR, autor);
        i.putExtra(EXTRA_TEXTO, texto);
        i.putExtra(EXTRA_SALA, sala);
        sendBroadcast(i);
    }

    // ─── API pública para a Activity atualizar o estado do serviço ─────────
    public static void atualizarSala(Context ctx, String sala, long ultimoId) {
        Intent i = new Intent(ctx, ChatService.class);
        i.putExtra("sala", sala);
        i.putExtra("ultimoId", ultimoId);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(i);
        } else {
            ctx.startService(i);
        }
    }

    public static void parar(Context ctx) {
        ctx.stopService(new Intent(ctx, ChatService.class));
    }
}
