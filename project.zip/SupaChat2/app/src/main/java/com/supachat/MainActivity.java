package com.supachat;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    // ─── Supabase ──────────────────────────────────────────────────────────
    private static final String SUPABASE_URL = "https://umeoupxrryeywomygvdo.supabase.co";
    private static final String SUPABASE_KEY = "sb_publishable_TsVRloDj3_tsZFGIMO5kLg_ZJhlmd0a";
    private static final MediaType JSON_TYPE = MediaType.parse("application/json; charset=utf-8");

    // ─── Telas ─────────────────────────────────────────────────────────────
    private View screenLogin, screenSalas, screenChat;

    // ─── Widgets ───────────────────────────────────────────────────────────
    private EditText editNome, editNovaSala, editMsg;
    private TextView txtSaudacao, txtNomeSala, txtOnline;
    private LinearLayout listaSalas, listaMsg;
    private ScrollView scrollChat;

    // ─── Estado ────────────────────────────────────────────────────────────
    private String nomeUsuario = "";
    private String salaAtual   = "";
    private long   ultimoId    = 0;

    // Cada sala: nome|criador|admins  (admins = lista separada por vírgula)
    private final List<String[]> salasData = new ArrayList<>();

    // ─── Infra ─────────────────────────────────────────────────────────────
    private OkHttpClient http;
    private Handler      handler;
    private Runnable     pollingRunnable;
    private SharedPreferences prefs;
    private BroadcastReceiver msgReceiver;

    // ───────────────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        http    = new OkHttpClient();
        handler = new Handler(Looper.getMainLooper());
        prefs   = getSharedPreferences("supachat", MODE_PRIVATE);

        bindViews();
        configurarListeners();
        registrarReceiver();
        pedirPermissaoNotificacao();

        String nomeSalvo = prefs.getString("nome", "");
        if (!nomeSalvo.isEmpty()) {
            nomeUsuario = nomeSalvo;
            mostrarSalas();
        }
    }

    // ─── Bind ──────────────────────────────────────────────────────────────
    private void bindViews() {
        screenLogin  = findViewById(R.id.screenLogin);
        screenSalas  = findViewById(R.id.screenSalas);
        screenChat   = findViewById(R.id.screenChat);
        editNome     = findViewById(R.id.editNome);
        txtSaudacao  = findViewById(R.id.txtSaudacao);
        listaSalas   = findViewById(R.id.listaSalas);
        editNovaSala = findViewById(R.id.editNovaSala);
        txtNomeSala  = findViewById(R.id.txtNomeSala);
        txtOnline    = findViewById(R.id.txtOnline);
        listaMsg     = findViewById(R.id.listaMsg);
        scrollChat   = findViewById(R.id.scrollChat);
        editMsg      = findViewById(R.id.editMsg);
    }

    private void configurarListeners() {
        findViewById(R.id.btnEntrar).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String nome = editNome.getText().toString().trim();
                if (nome.isEmpty()) { toast("Digite seu nome"); return; }
                nomeUsuario = nome;
                prefs.edit().putString("nome", nome).apply();
                mostrarSalas();
            }
        });

        findViewById(R.id.btnSair).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                pararPolling();
                ChatService.parar(MainActivity.this);
                nomeUsuario = "";
                prefs.edit().remove("nome").apply();
                mostrar(screenLogin);
            }
        });

        findViewById(R.id.btnCriarSala).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String nome = editNovaSala.getText().toString().trim();
                if (nome.isEmpty()) { toast("Digite o nome da sala"); return; }
                criarSala(nome);
            }
        });

        findViewById(R.id.btnVoltar).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                pararPolling();
                // Serviço continua rodando em bg monitorando a sala
                salaAtual = "";
                mostrarSalas();
            }
        });

        findViewById(R.id.btnEnviar).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String texto = editMsg.getText().toString().trim();
                if (texto.isEmpty()) return;
                enviarMensagem(texto);
            }
        });
    }

    // ─── BroadcastReceiver (mensagens chegando enquanto Activity está aberta)
    private void registrarReceiver() {
        msgReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent intent) {
                // Apenas atualiza se a Activity está no chat e é a mesma sala
                String sala = intent.getStringExtra(ChatService.EXTRA_SALA);
                if (screenChat.getVisibility() == View.VISIBLE
                        && sala != null && sala.equals(salaAtual)) {
                    buscarNovaMensagens();
                }
            }
        };
        IntentFilter filter = new IntentFilter(ChatService.ACTION_NOVA_MSG);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(msgReceiver, filter, RECEIVER_EXPORTED);
        } else {
            registerReceiver(msgReceiver, filter);
        }
    }

    private void pedirPermissaoNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
            }
        }
    }

    // ─── Navegação ─────────────────────────────────────────────────────────
    private void mostrar(View tela) {
        screenLogin.setVisibility(View.GONE);
        screenSalas.setVisibility(View.GONE);
        screenChat.setVisibility(View.GONE);
        tela.setVisibility(View.VISIBLE);
    }

    private void mostrarSalas() {
        mostrar(screenSalas);
        txtSaudacao.setText("Olá, " + nomeUsuario + "!");
        carregarSalas();
    }

    private void abrirSala(String sala) {
        salaAtual = sala;
        ultimoId  = 0;
        listaMsg.removeAllViews();
        txtNomeSala.setText("# " + sala);
        txtNomeSala.setContentDescription("Sala " + sala);
        mostrar(screenChat);
        carregarHistorico();
        iniciarPolling();
        ChatService.atualizarSala(this, sala, 0);
    }

    // ─── Salas ─────────────────────────────────────────────────────────────
    private void carregarSalas() {
        // Busca nome, criador e lista de admins
        String url = SUPABASE_URL + "/rest/v1/salas?select=nome,criador,admins&order=nome.asc";
        Request req = new Request.Builder()
                .url(url)
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .get().build();

        http.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                runOnUiThread(new Runnable() {
                    @Override public void run() { toast("Erro ao carregar salas"); }
                });
            }
            @Override public void onResponse(Call call, Response resp) throws IOException {
                final String body = resp.body().string();
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try {
                            JSONArray arr = new JSONArray(body);
                            salasData.clear();
                            for (int i = 0; i < arr.length(); i++) {
                                JSONObject o = arr.getJSONObject(i);
                                String nome    = o.optString("nome", "");
                                String criador = o.optString("criador", "");
                                String admins  = o.optString("admins", "");
                                salasData.add(new String[]{nome, criador, admins});
                            }
                            renderizarSalas();
                        } catch (Exception e) { toast("Erro ao processar salas"); }
                    }
                });
            }
        });
    }

    private void renderizarSalas() {
        listaSalas.removeAllViews();
        if (salasData.isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("Nenhuma sala. Crie uma!");
            tv.setTextColor(Color.parseColor("#888888"));
            tv.setPadding(16, 16, 16, 16);
            listaSalas.addView(tv);
            return;
        }

        for (final String[] sala : salasData) {
            final String nomeSala    = sala[0];
            final String criadorSala = sala[1];
            final String adminsSala  = sala[2];
            boolean podeExcluir = podeExcluirSala(criadorSala, adminsSala);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams lpRow = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lpRow.setMargins(0, 0, 0, 8);
            row.setLayoutParams(lpRow);
            row.setBackgroundColor(Color.parseColor("#16213e"));

            // Botão entrar
            Button btnEntrar = new Button(this);
            btnEntrar.setText("# " + nomeSala);
            btnEntrar.setTextColor(Color.WHITE);
            btnEntrar.setAllCaps(false);
            btnEntrar.setTextSize(15f);
            btnEntrar.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            btnEntrar.setPadding(28, 18, 28, 18);
            String descAcessib = "Sala " + nomeSala;
            if (!criadorSala.isEmpty()) descAcessib += ", criada por " + criadorSala;
            descAcessib += ". Toque duas vezes para entrar.";
            btnEntrar.setContentDescription(descAcessib);
            LinearLayout.LayoutParams lpBtn = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            btnEntrar.setLayoutParams(lpBtn);
            btnEntrar.setBackgroundColor(Color.TRANSPARENT);
            final String nomeFinal = nomeSala;
            btnEntrar.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { abrirSala(nomeFinal); }
            });
            row.addView(btnEntrar);

            // Botão ADM (apenas criador pode dar permissão)
            if (nomeUsuario.equals(criadorSala)) {
                Button btnAdm = new Button(this);
                btnAdm.setText("ADM");
                btnAdm.setTextColor(Color.parseColor("#e94560"));
                btnAdm.setAllCaps(false);
                btnAdm.setTextSize(11f);
                btnAdm.setPadding(12, 8, 12, 8);
                btnAdm.setBackgroundColor(Color.TRANSPARENT);
                btnAdm.setContentDescription("Gerenciar administradores da sala " + nomeSala);
                btnAdm.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        abrirGerenciarAdm(nomeSala, criadorSala, adminsSala);
                    }
                });
                row.addView(btnAdm);
            }

            // Botão excluir (criador ou adm)
            if (podeExcluir) {
                Button btnDel = new Button(this);
                btnDel.setText("✕");
                btnDel.setTextColor(Color.parseColor("#e94560"));
                btnDel.setAllCaps(false);
                btnDel.setTextSize(16f);
                btnDel.setPadding(16, 8, 16, 8);
                btnDel.setBackgroundColor(Color.TRANSPARENT);
                btnDel.setContentDescription("Excluir sala " + nomeSala);
                btnDel.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        confirmarExcluirSala(nomeSala);
                    }
                });
                row.addView(btnDel);
            }

            listaSalas.addView(row);
        }
    }

    // Verifica se o usuário atual pode excluir a sala
    private boolean podeExcluirSala(String criador, String admins) {
        if (nomeUsuario.equals(criador)) return true;
        if (admins == null || admins.isEmpty()) return false;
        String[] lista = admins.split(",");
        for (String a : lista) {
            if (nomeUsuario.equals(a.trim())) return true;
        }
        return false;
    }

    private void confirmarExcluirSala(final String nome) {
        new AlertDialog.Builder(this)
                .setTitle("Excluir sala")
                .setMessage("Excluir \"" + nome + "\"? As mensagens também serão apagadas.")
                .setPositiveButton("Excluir", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        excluirSala(nome);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void excluirSala(final String nome) {
        // Primeiro apaga as mensagens, depois a sala
        Request reqMsg = new Request.Builder()
                .url(SUPABASE_URL + "/rest/v1/mensagens?sala=eq." + nome)
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .delete().build();

        http.newCall(reqMsg).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                runOnUiThread(new Runnable() {
                    @Override public void run() { toast("Erro ao excluir mensagens"); }
                });
            }
            @Override public void onResponse(Call call, Response resp) throws IOException {
                // Agora apaga a sala
                Request reqSala = new Request.Builder()
                        .url(SUPABASE_URL + "/rest/v1/salas?nome=eq." + nome)
                        .header("apikey", SUPABASE_KEY)
                        .header("Authorization", "Bearer " + SUPABASE_KEY)
                        .delete().build();

                http.newCall(reqSala).enqueue(new Callback() {
                    @Override public void onFailure(Call call2, IOException e2) {
                        runOnUiThread(new Runnable() {
                            @Override public void run() { toast("Erro ao excluir sala"); }
                        });
                    }
                    @Override public void onResponse(Call call2, Response resp2) throws IOException {
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                toast("Sala \"" + nome + "\" excluída");
                                carregarSalas();
                            }
                        });
                    }
                });
            }
        });
    }

    // ─── Gerenciar ADMs ────────────────────────────────────────────────────
    private void abrirGerenciarAdm(final String nomeSala, final String criador, final String adminsAtual) {
        final EditText input = new EditText(this);
        input.setHint("Nome do usuário para dar ADM");
        input.setText(adminsAtual);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        input.setContentDescription("Campo para adicionar administradores. Separe nomes por vírgula.");

        new AlertDialog.Builder(this)
                .setTitle("Admins de #" + nomeSala)
                .setMessage("Digite os nomes separados por vírgula.\nCriador: " + criador)
                .setView(input)
                .setPositiveButton("Salvar", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        String novaLista = input.getText().toString().trim();
                        salvarAdmins(nomeSala, novaLista);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void salvarAdmins(final String nomeSala, final String admins) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("admins", admins);
            RequestBody body = RequestBody.create(obj.toString(), JSON_TYPE);
            Request req = new Request.Builder()
                    .url(SUPABASE_URL + "/rest/v1/salas?nome=eq." + nomeSala)
                    .header("apikey", SUPABASE_KEY)
                    .header("Authorization", "Bearer " + SUPABASE_KEY)
                    .header("Content-Type", "application/json")
                    .header("Prefer", "return=minimal")
                    .patch(body).build();

            http.newCall(req).enqueue(new Callback() {
                @Override public void onFailure(Call call, IOException e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() { toast("Erro ao salvar admins"); }
                    });
                }
                @Override public void onResponse(Call call, Response resp) throws IOException {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            toast("Admins atualizados!");
                            carregarSalas();
                        }
                    });
                }
            });
        } catch (Exception e) { toast("Erro ao salvar admins"); }
    }

    private void criarSala(final String nome) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("nome", nome);
            obj.put("criador", nomeUsuario);
            obj.put("admins", "");
            RequestBody body = RequestBody.create(obj.toString(), JSON_TYPE);
            Request req = new Request.Builder()
                    .url(SUPABASE_URL + "/rest/v1/salas")
                    .header("apikey", SUPABASE_KEY)
                    .header("Authorization", "Bearer " + SUPABASE_KEY)
                    .header("Content-Type", "application/json")
                    .header("Prefer", "return=minimal")
                    .post(body).build();

            http.newCall(req).enqueue(new Callback() {
                @Override public void onFailure(Call call, IOException e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() { toast("Erro ao criar sala"); }
                    });
                }
                @Override public void onResponse(Call call, Response resp) throws IOException {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            editNovaSala.setText("");
                            carregarSalas();
                            toast("Sala \"" + nome + "\" criada!");
                        }
                    });
                }
            });
        } catch (Exception e) { toast("Erro ao criar sala"); }
    }

    // ─── Mensagens ─────────────────────────────────────────────────────────
    private void carregarHistorico() {
        String url = SUPABASE_URL + "/rest/v1/mensagens"
                + "?sala=eq." + salaAtual
                + "&order=id.asc&limit=100";

        Request req = new Request.Builder()
                .url(url)
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .get().build();

        http.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {}
            @Override public void onResponse(Call call, Response resp) throws IOException {
                final String body = resp.body().string();
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try {
                            JSONArray arr = new JSONArray(body);
                            listaMsg.removeAllViews();
                            for (int i = 0; i < arr.length(); i++) {
                                JSONObject msg = arr.getJSONObject(i);
                                adicionarMensagem(msg);
                                long id = msg.getLong("id");
                                if (id > ultimoId) ultimoId = id;
                            }
                            scrollBaixo();
                            // Atualiza serviço com ultimoId atual
                            ChatService.atualizarSala(MainActivity.this, salaAtual, ultimoId);
                        } catch (Exception e) { toast("Erro ao carregar histórico"); }
                    }
                });
            }
        });
    }

    private void buscarNovaMensagens() {
        if (salaAtual.isEmpty()) return;
        String url = SUPABASE_URL + "/rest/v1/mensagens"
                + "?sala=eq." + salaAtual
                + "&id=gt." + ultimoId
                + "&order=id.asc";

        Request req = new Request.Builder()
                .url(url)
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .get().build();

        http.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {}
            @Override public void onResponse(Call call, Response resp) throws IOException {
                final String body = resp.body().string();
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try {
                            JSONArray arr = new JSONArray(body);
                            for (int i = 0; i < arr.length(); i++) {
                                JSONObject msg = arr.getJSONObject(i);
                                adicionarMensagem(msg);
                                long id = msg.getLong("id");
                                if (id > ultimoId) ultimoId = id;
                            }
                            if (arr.length() > 0) {
                                scrollBaixo();
                                ChatService.atualizarSala(MainActivity.this, salaAtual, ultimoId);
                            }
                        } catch (Exception e) { /* silencioso */ }
                    }
                });
            }
        });
    }

    private void enviarMensagem(final String texto) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("sala",  salaAtual);
            obj.put("autor", nomeUsuario);
            obj.put("texto", texto);
            RequestBody body = RequestBody.create(obj.toString(), JSON_TYPE);
            Request req = new Request.Builder()
                    .url(SUPABASE_URL + "/rest/v1/mensagens")
                    .header("apikey", SUPABASE_KEY)
                    .header("Authorization", "Bearer " + SUPABASE_KEY)
                    .header("Content-Type", "application/json")
                    .header("Prefer", "return=minimal")
                    .post(body).build();

            http.newCall(req).enqueue(new Callback() {
                @Override public void onFailure(Call call, IOException e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() { toast("Falha ao enviar"); }
                    });
                }
                @Override public void onResponse(Call call, Response resp) throws IOException {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            editMsg.setText("");
                            buscarNovaMensagens();
                        }
                    });
                }
            });
        } catch (Exception e) { toast("Erro ao enviar"); }
    }

    // ─── UI: Balão de mensagem ─────────────────────────────────────────────
    private void adicionarMensagem(JSONObject msg) {
        try {
            String autor = msg.getString("autor");
            String texto = msg.getString("texto");
            String hora  = "";
            if (msg.has("created_at")) {
                hora = formatarHora(msg.getString("created_at"));
            }
            boolean proprio = autor.equals(nomeUsuario);

            LinearLayout container = new LinearLayout(this);
            container.setOrientation(LinearLayout.VERTICAL);
            container.setPadding(8, 4, 8, 4);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            container.setLayoutParams(lp);
            container.setGravity(proprio ? Gravity.END : Gravity.START);

            LinearLayout balao = new LinearLayout(this);
            balao.setOrientation(LinearLayout.VERTICAL);
            balao.setPadding(24, 14, 24, 14);
            balao.setBackgroundColor(Color.parseColor(proprio ? "#0f3460" : "#222244"));

            LinearLayout.LayoutParams lpBalao = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lpBalao.setMargins(proprio ? 80 : 0, 0, proprio ? 0 : 80, 0);
            balao.setLayoutParams(lpBalao);

            if (!proprio) {
                TextView tvAutor = new TextView(this);
                tvAutor.setText(autor);
                tvAutor.setTextColor(Color.parseColor("#e94560"));
                tvAutor.setTextSize(12f);
                tvAutor.setTypeface(null, Typeface.BOLD);
                balao.addView(tvAutor);
            }

            TextView tvTexto = new TextView(this);
            tvTexto.setText(texto);
            tvTexto.setTextColor(Color.WHITE);
            tvTexto.setTextSize(15f);
            balao.addView(tvTexto);

            if (!hora.isEmpty()) {
                TextView tvHora = new TextView(this);
                tvHora.setText(hora);
                tvHora.setTextColor(Color.parseColor("#888888"));
                tvHora.setTextSize(10f);
                tvHora.setGravity(Gravity.END);
                balao.addView(tvHora);
            }

            // Acessibilidade TalkBack
            String desc = (proprio ? "Você" : autor) + " disse: " + texto;
            if (!hora.isEmpty()) desc += ". Enviado às " + hora;
            balao.setContentDescription(desc);
            balao.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);

            container.addView(balao);
            listaMsg.addView(container);

        } catch (Exception e) { /* ignora */ }
    }

    // ─── Hora corrigida: converte UTC→local ────────────────────────────────
    // O Supabase retorna timestamps em UTC: "2024-01-15T13:45:00.000000+00:00"
    // Precisamos converter para o fuso local do dispositivo.
    private String formatarHora(String iso) {
        try {
            // Remove microssegundos e offset para simplificar o parse
            // Formato: 2024-01-15T13:45:00.123456+00:00 ou 2024-01-15T13:45:00+00:00
            String s = iso;
            // Remove offset final (+00:00 ou -03:00 etc.) — sempre UTC no Supabase
            int plusIdx  = s.lastIndexOf('+');
            int minusIdx = s.lastIndexOf('-');
            int offsetIdx = -1;
            if (plusIdx > 10) offsetIdx = plusIdx;
            else if (minusIdx > 10) offsetIdx = minusIdx;
            if (offsetIdx > 0) s = s.substring(0, offsetIdx);
            // Remove microssegundos (mantém só HH:mm:ss)
            int dotIdx = s.indexOf('.');
            if (dotIdx > 0) s = s.substring(0, dotIdx);
            // s agora: "2024-01-15T13:45:00"
            SimpleDateFormat sdfUtc = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault());
            sdfUtc.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date date = sdfUtc.parse(s);
            if (date == null) return iso.length() >= 16 ? iso.substring(11, 16) : iso;
            SimpleDateFormat sdfLocal = new SimpleDateFormat("HH:mm", Locale.getDefault());
            sdfLocal.setTimeZone(TimeZone.getDefault()); // fuso do dispositivo
            return sdfLocal.format(date);
        } catch (Exception e) {
            // Fallback: pega só os caracteres 11-16 da string bruta
            try { return iso.substring(11, 16); } catch (Exception ex) { return ""; }
        }
    }

    // ─── Polling ───────────────────────────────────────────────────────────
    private void iniciarPolling() {
        pararPolling();
        pollingRunnable = new Runnable() {
            @Override public void run() {
                buscarNovaMensagens();
                handler.postDelayed(this, 3000);
            }
        };
        handler.postDelayed(pollingRunnable, 3000);
    }

    private void pararPolling() {
        if (pollingRunnable != null) {
            handler.removeCallbacks(pollingRunnable);
            pollingRunnable = null;
        }
    }

    // ─── Utilidades ────────────────────────────────────────────────────────
    private void scrollBaixo() {
        scrollChat.post(new Runnable() {
            @Override public void run() { scrollChat.fullScroll(View.FOCUS_DOWN); }
        });
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ─── Ciclo de vida ─────────────────────────────────────────────────────
    @Override
    protected void onDestroy() {
        super.onDestroy();
        pararPolling();
        try { unregisterReceiver(msgReceiver); } catch (Exception e) { /* ignora */ }
    }

    @Override
    public void onBackPressed() {
        if (screenChat.getVisibility() == View.VISIBLE) {
            pararPolling();
            salaAtual = "";
            mostrarSalas();
        } else if (screenSalas.getVisibility() == View.VISIBLE) {
            // mantém na tela de salas
        } else {
            super.onBackPressed();
        }
    }
}
